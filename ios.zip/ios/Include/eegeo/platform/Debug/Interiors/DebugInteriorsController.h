// Copyright eeGeo Ltd (2012-2014), All Rights Reserved

#pragma once

#include "Interiors.h"
#include "ICallback.h"
#include "CallbackCollection.h"

namespace Eegeo
{
    namespace Debug
    {
        namespace Interiors
        {
            class DebugInteriorsController
            {
            public:
                DebugInteriorsController(Resources::Interiors::InteriorSelectionModel& interiorSelectionModel,
                                         Resources::Interiors::InteriorInteractionModel& interiorInteractionModel,
                                         Resources::Interiors::InteriorTransitionModel& interiorTransitionModel);
                ~DebugInteriorsController();
                
                void ExitInterior();
                void UpFloor();
                void DownFloor();
                void ToggleExpanded();
                bool IsInteriorModeEnabled() const;
                bool CanExpand() const;
                
                void RegisterViewModelChangedCallback(Helpers::ICallback0& callback);
                void UnRegisterViewModelChangedCallback(Helpers::ICallback0& callback);
                
                
                
            private:
 
                Resources::Interiors::InteriorInteractionModel& m_interiorInteractionModel;
                Resources::Interiors::InteriorSelectionModel& m_interiorSelectionModel;
                Resources::Interiors::InteriorTransitionModel& m_interiorTransitionModel;

                Helpers::TCallback0<DebugInteriorsController> m_interiorsStateChangedCallback;
                Helpers::TCallback0<DebugInteriorsController> m_interiorsTransitionChangedCallback;
                Helpers::TCallback0<DebugInteriorsController> m_interiorsInteractionStateChangedCallback;
                
                
                Helpers::CallbackCollection0 m_viewModelChangedChangedCallbacks;
                
                void OnInteriorsStateChanged();
                void OnInteriorsTransitionChanged();
                void OnInteriorsInteractionStateChanged();
                
                void NotifyViewModelChanged();
            };
        }
    }
}
