// Copyright eeGeo Ltd (2012-2016), All Rights Reserved

#pragma once

#include "PerformanceTestRunner.h"

namespace Eegeo
{
    namespace Debug
    {
        class SystestSplines
        {
        public:            
            static Profile::SplineData CreateJapanSplineData();
            static Profile::SplineData CreateSanFranciscoSplineData();
            static Profile::SplineData CreateLondonSplineData();
        };
    }
}