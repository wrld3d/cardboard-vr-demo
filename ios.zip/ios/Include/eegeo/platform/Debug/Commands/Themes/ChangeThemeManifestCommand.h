// Copyright eeGeo Ltd 2015, All Rights Reserved

#pragma once

#include "Command.h"
#include "Commands.h"

namespace Eegeo
{
    namespace Debug
    {
        namespace Commands
        {
            namespace Themes
            {
                class ChangeThemeManifestCommand : public Command
                {
                public:
                    ChangeThemeManifestCommand();
                    
                    bool TryExecute(
                                    const std::vector<std::string>& arguments,
                                    const ICommandTerminalOutput& commandTerminal) const;
                };
            }
        }
    }
}
