// Copyright eeGeo Ltd (2012-2014), All Rights Reserved

#pragma once

namespace Eegeo
{
    class Quaternion;
	class v2;
	class v3;
    class dv2;
	class dv3;
	class v4;
    class dv4;
	class m33;
	class m44;
	class dm44;
	class dm33;
}
