// Copyright eeGeo Ltd (2012-2014), All Rights Reserved

#pragma once

#include "Types.h"

namespace Eegeo
{
	u32 CRC32	( const u8* pBuffer, size_t len );
}
